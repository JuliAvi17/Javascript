function adaptarVista() {
    var desktopElements = document.getElementsByClassName('desktop');
    var mobileElements = document.getElementsByClassName('mobile');
    if (window.innerWidth < 601) {
      // Vista móvil
    for (var i = 0; i < desktopElements.length; i++) {
        desktopElements[i].style.display = 'none';
    }
    for (var i = 0; i < mobileElements.length; i++) {
        mobileElements[i].style.display = 'block';
    }
    } else {
      // Vista de escritorio
    for (var i = 0; i < desktopElements.length; i++) {
        desktopElements[i].style.display = 'block';
    }
    for (var i = 0; i < mobileElements.length; i++) {
        mobileElements[i].style.display = 'none';
    }
    }
}
  // Adaptar vista inicialmenteadaptarVista();
  // Volver a adaptar la vista al cambiar el tamaño de la ventana
window.addEventListener('resize', adaptarVista);