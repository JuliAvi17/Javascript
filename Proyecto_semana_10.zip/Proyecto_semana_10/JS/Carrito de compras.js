// PRODUCTOS
const productos = [
    // Herramientas eléctricas
    {
        id: "herramienta electrica 01",
        titulo: "Herramienta eléctrica 1",
        imagen: "../img/Herramientas eléctricas 01.png",
        categoria: {
            nombre: "Herramientas eléctricas",
            id: "Herramientas"
        },
        precio: 95000
    },
    {
        id: "herramienta electrica 02",
        titulo: "Herramienta eléctrica 2",
        imagen: "../img/Herramientas eléctricas 02.jpeg",
        categoria: {
            nombre: "Herramientas eléctricas",
            id: "Herramientas"
        },
        precio: 70000
    },
    {
        id: "Herramienta electrica 03",
        titulo: "Herramienta eléctrica 3",
        imagen: "../img/Herramientas eléctricas 03.jpeg",
        categoria: {
            nombre: "Herramientas eléctricas",
            id: "Herramientas"
        },
        precio: 150000
    },
    {
        id: "Herramienta electrica 04",
        titulo: "Herramienta eléctrica 4",
        imagen: "../img/Herramientas eléctricas 04.jpg",
        categoria: {
            nombre: "Herramientas eléctricas",
            id: "Herramientas"
        },
        precio: 480000
    },
    {
        id: "Herramienta electrica 05",
        titulo: "Herramienta eléctrica 5",
        imagen: "../img/Herramientas eléctricas 05.jpeg",
        categoria: {
            nombre: "Herramientas eléctricas",
            id: "Herramientas"
        },
        precio: 600000
    },
    // Herramientas manuales
    {
        id: "Herramienta manual 01",
        titulo: "Herramienta manual 1",
        imagen: "../img/Herramienta manual 1.jpeg",
        categoria: {
            nombre: "Herramienta manual",
            id: "HerramientasM"
        },
        precio: 35000
    },
    {
        id: "Herramienta manual 02",
        titulo: "Herramienta manual 2",
        imagen: "../img/Herramienta manual 2.jpg",
        categoria: {
            nombre: "Herramienta manual",
            id: "HerramientasM"
        },
        precio: 65000
    },
    {
        id: "Herramienta manual 03",
        titulo: "Herramienta manual 3",
        imagen: "../img/Herramienta manual 3.jpeg",
        categoria: {
            nombre: "Herramienta manual",
            id: "HerramientasM"
        },
        precio: 27000
    },
    {
        id: "Herramienta manual 04",
        titulo: "Herramienta manual 4",
        imagen: "../img/Herramienta manual 4.jpeg",
        categoria: {
            nombre: "Herramienta manual",
            id: "HerramientasM"
        },
        precio: 50000
    },
    {
        id: "Herramienta manual 05",
        titulo: "Herramienta manual 5",
        imagen: "../img/Herramienta manual 5.jpeg",
        categoria: {
            nombre: "Herramienta manual",
            id: "HerramientasM"
        },
        precio: 80000
    },
    {
        id: "Herramienta manual 06",
        titulo: "Herramienta manual 6",
        imagen: " ../img/Herramienta manual 6.jpg",
        categoria: {
            nombre: "Herramienta manual",
            id: "HerramientasM"
        },
        precio: 95000
    },
    {
        id: "Herramienta manual 07",
        titulo: "Herramienta manual 7",
        imagen: "../img/Herramienta manual 7.jpeg",
        categoria: {
            nombre: "Herramienta manual",
            id: "HerramientasM"
        },
        precio: 150000
    },
    {
        id: "Herramienta manual 08",
        titulo: "Herramienta manual 8",
        imagen: "../img/Herramienta manual 8.jpg",
        categoria: {
            nombre: "Herramienta manual",
            id: "HerramientasM"
        },
        precio: 65000
    },
    // Materiales de construcción
    {
        id: "Materiales 01",
        titulo: "Material 1",
        imagen: "../img/Materiales 1.jpeg",
        categoria: {
            nombre: "Materiales construcción",
            id: "Materiales"
        },
        precio: 30000
    },
    {
        id: "Materiales 02",
        titulo: "Material 2",
        imagen: "../img/Materiales 2.jpg",
        categoria: {
            nombre: "Materiales construcción",
            id: "Materiales"
        },
        precio: 97500
    },
    {
        id: "Materiales 03",
        titulo: "Material 3",
        imagen: "../img/Materiales 3.jpeg",
        categoria: {
            nombre: "Materiales construcción",
            id: "Materiales"
        },
        precio: 787500
    },
    {
        id: "Materiales 04",
        titulo: "Material 4",
        imagen: "../img/Materiales 4.jpeg",
        categoria: {
            nombre: "Materiales construcción",
            id: "Materiales"
        },
        precio: 1187550
    },
    {
        id: "Materiales 05",
        titulo: "Material 5",
        imagen: "../img/Materiales 5.jpeg",
        categoria: {
            nombre: "Materiales construcción",
            id: "Materiales"
        },
        precio: 76000
    }
];
const contenedorProductos = document.querySelector("#contenedor-productos");
const botonesCategorias = document.querySelectorAll(".boton-categoria");
const tituloPrincipal = document.querySelector("#titulo-principal");
let botonesAgregar = document.querySelectorAll(".producto-agregar");
const numerito = document.querySelector("#numerito");
function cargarProductos(productosElegidos) {
    contenedorProductos.innerHTML = "";
    productosElegidos.forEach(producto => {
        const div = document.createElement("div");
        div.classList.add("producto");
        div.innerHTML = `
            <img class="producto-imagen" src="${producto.imagen}" alt="${producto.titulo}">
            <div class="producto-detalles">
                <h3 class="producto-titulo">${producto.titulo}</h3>
                <p class="producto-precio">$${producto.precio}</p>
                <button class="producto-agregar" id="${producto.id}">Agregar</button>
            </div>
        `;
        contenedorProductos.append(div);
    })
    actualizarBotonesAgregar();
}
cargarProductos(productos);
botonesCategorias.forEach(boton => {
    boton.addEventListener("click", (e) => {
        botonesCategorias.forEach(boton => boton.classList.remove("active"));
        e.currentTarget.classList.add("active");
        if (e.currentTarget.id != "todos") {
            const productoCategoria = productos.find(producto => producto.categoria.id === e.currentTarget.id);
            tituloPrincipal.innerText = productoCategoria.categoria.nombre;
            const productosBoton = productos.filter(producto => producto.categoria.id === e.currentTarget.id);
            cargarProductos(productosBoton);
        } else {
            tituloPrincipal.innerText = "Todos los productos";
            cargarProductos(productos);
        }
    })
});
function actualizarBotonesAgregar() {
    botonesAgregar = document.querySelectorAll(".producto-agregar");
    botonesAgregar.forEach(boton => {
        boton.addEventListener("click", agregarAlCarrito);
    });
}
let productosEnCarrito;
let productosEnCarritoLS = localStorage.getItem("productos-en-carrito");
if (productosEnCarritoLS) {
    productosEnCarrito = JSON.parse(productosEnCarritoLS);
    actualizarNumerito();
} else {
    productosEnCarrito = [];
}
function agregarAlCarrito(e) {
    const idBoton = e.currentTarget.id;
    const productoAgregado = productos.find(producto => producto.id === idBoton);
    if(productosEnCarrito.some(producto => producto.id === idBoton)) {
        const index = productosEnCarrito.findIndex(producto => producto.id === idBoton);
        productosEnCarrito[index].cantidad++;
    } else {
        productoAgregado.cantidad = 1;
        productosEnCarrito.push(productoAgregado);
    }
    actualizarNumerito();
    localStorage.setItem("productos-en-carrito", JSON.stringify(productosEnCarrito));
}
function actualizarNumerito() {
    let nuevoNumerito = productosEnCarrito.reduce((acc, producto) => acc + producto.cantidad, 0);
    numerito.innerText = nuevoNumerito;
}